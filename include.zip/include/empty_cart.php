
<div class="title">К сожалению, ваша корзина пуста</div>
 
<p>Исправить это недоразумение очень просто: <a href="<?=SITE_DIR?>catalog/">выберите в каталоге</a> интересующий товар и нажмите кнопку &laquo;В корзину&raquo;. </p><br />
 
<a href="<?=SITE_DIR?>catalog/"  class="button close"><span>Вернуться</span></a>