<div class = "row">
	<a class = "vkh" href="https://vk.com/gipfel.official"><i class="fa fa-vk" aria-hidden="true"></i></a>
	<a class = "fbh" href="https://www.facebook.com/gipfel.ru/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
</div>
<div class = "row">
	<a class = "okh" href="https://ok.ru/gipfel.official"><i class="fa fa-odnoklassniki" aria-hidden="true"></i></a>
	<a class = "inh" href="https://www.instagram.com/gipfel.official/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
</div>