<? if ($GLOBALS["MCUR"]=='UAH') {$fffm = 'info@gipfel.ua';} else {$fffm = 'info@gipfel.ru';} ?>


	 <a style="position:relative;top:65px;" href="mailto:<?=$fffm?>"><?=$fffm?></a><br>