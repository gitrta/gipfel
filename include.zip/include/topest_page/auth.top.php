<?$APPLICATION->IncludeComponent("bitrix:system.auth.form", "top", array(
	"REGISTER_URL" => SITE_DIR."auth/registration/",
	"FORGOT_PASSWORD_URL" => SITE_DIR."auth/forgot-password/",
	"PROFILE_URL" => SITE_DIR."personal/",
	"SHOW_ERRORS" => "Y"
	)
);?>