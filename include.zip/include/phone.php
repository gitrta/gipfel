<a href="tel:+7(495)222-15-15" rel="nofollow">8 (495) 222-15-15</a>
<a href="tel:+7(800)700-34-88" rel="nofollow">8 (800) 700-34-88</a>