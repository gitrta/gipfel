<?
include_once $_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/itprosteer.newpost/files/ajax_newpost/ajax.php";
?>
