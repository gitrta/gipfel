<img src="/include/mastercard.png" alt="MasterCard" title="MasterCard" />
<img src="/include/visa.png" alt="visa" title="visa" />
<img src="/include/yandex.png" alt="Yandex Money" title="Yandex Money" />
<img src="/include/webmoney.png" alt="Webmoney" title="Webmoney" />
<img src="/include/qiwi.png" alt="qiwi" title="qiwi" />