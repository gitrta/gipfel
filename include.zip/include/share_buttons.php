<script type="text/javascript" src="//yandex.st/share/share.js" charset="utf-8"></script>
<div class="share_wrapp">
	<div class="text button transparent"><?=GetMessage("SHARE_BUTTON");?></div>
	<div class="yashare-auto-init shares" data-yashareL10n="ru" data-yashareType="none" data-yashareQuickServices="yaru,vkontakte,facebook,twitter,odnoklassniki,moimir,gplus"></div> 
</div>