<span class="medium">Телефон</span><br/>
<span class="grey"><a href="tel:+7(495)222-15-15" rel="nofollow">+7 (495) 222-15-15</a></span><br/><br/>
<span class="medium">E-mail</span> <br>
<a rel="nofollow" href="mailto:info@gipfel.ru">info@gipfel.ru</a>